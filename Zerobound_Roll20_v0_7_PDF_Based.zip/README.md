# Zerobound — Roll20 Character Sheet (v0.7 PDF recreation)

**Source:** `Zerobound_Character_Sheet_v0_7(1).pdf` supplied by the creator. This build intentionally follows that document, **not v0.8**. The original four character-record pages are now tabs in the same order, with white paper, deep-teal headings, tan accent lines, and matching labels.

## Roll20 Plus annual subscription: important
Roll20 Plus can use published community sheets, but it **cannot** select custom HTML/CSS as the game's Character Sheet Template. The custom editor and Sheet Sandbox require **Pro**. This ZIP does NOT automatically install into a Plus game.

You can:
1. **Publish to the Roll20 community repository:** submit the `Zerobound` folder as a pull request at https://github.com/Roll20/roll20-character-sheets . Once approved and available in Roll20's game-sheet dropdown, choose it in your game settings with Plus. It is not published yet. Community submissions may need corrections after Roll20 testing; Chrome/Firefox live testing is expected.
2. **Use a Pro-owned game to test/install:** an account with Pro creates a game, chooses Game Settings > Character Sheet Template > Custom, turns Legacy Sanitization OFF and pastes `zerobound.html` and `zerobound.css` into the HTML and CSS tabs. Save and launch. Players can join without Pro themselves.
3. **Play now on Plus without a custom sheet:** Keep the supplied PDF beside Roll20 or share it as a handout/link as allowed; use Roll20's built-in Character > Attributes & Abilities to make your own stats, attack and skill macros until the community sheet is published.

## Fidelity to the source PDF
- **Tab 1: CHARACTER & COMBAT.** Exactly eight attributes (STR AGI END INT AWA INST WILL PRES), training checkbox and save field, 18 listed skills with Rank / Spec. / Misc. / Total, three attacks with ATTACK / DAMAGE / RANGE / LOAD / PROPS., the three Guard/Wounds/Stress tracks, AP Spent, Reaction, Move Left, three class-resource slots, Conditions/Injuries and death saves.
- **Tab 2: ADVANCEMENT & ABILITIES.** Level 1/4/8/12/16/20 feat or ASI choices, 2/6/10/14/18 talent choices, attribute-build columns, rank-cap fields, class features and specializations.
- **Tab 3: LOADOUT & IDENTITY.** Credits, mass/carry/augmentation, repeating inventory, repeating infusions/upgrades, traits, training, contacts and goals.
- **Tab 4: POWERS & CHANNELS.** Casting source, casting attribute, Power Attack, Save DC, Focus, available grades 0–5, concentration, repeating known powers.

## Automated calculations
Attribute modifier = floor((score − 10) / 2); saving throws add PB only if checkbox trained. The 18 skill totals add relevant attribute mod + entered rank + entered specialization + misc, in accordance with page one. Only enter a **specialization value** when the specialization applies to the current roll. Page-one Defense, Initiative, Speed, maximum Wounds and Stress Capacity, Power Attack and save DC are calculated from the Zerobound **core v0.7** rules; corresponding misc fields allow adjustment. All other numbers stay directly editable from the PDF. Class features, special actions, glancing hits, critical damage and armor/Guard damage reductions require the players or GM to resolve them; attack/damage roll buttons do not apply them automatically.

**Important:** To keep PDF fidelity, the Attribute Build base/race/ASI/augment boxes on Tab 2 are historical reference entries; the Final column automatically shows the live attribute score from Tab 1. Changing the build columns does not recalculate your main attribute. Roll20 roll buttons and auto-calculated outputs are additions for VTT usage.

## Testing status
Code structure and sheetworker JavaScript can be statically checked, and the print-style preview can be rendered. **The sheet has not been tested in Roll20's live editor/sandbox**, which only a Pro user can access. Community publishing is a review and approval process, not automatic.
